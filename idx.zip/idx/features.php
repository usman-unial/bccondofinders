
<!DOCTYPE html>
<html lang="en">
<head>

<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MF9R6M5');</script>

<title>IDX Features - IDX Boost</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="#d32752">
<meta name="theme-color" content="#d32752">
<meta name="msapplication-navbutton-color" content="#d32752">
<link rel="alternate" href="https://www.idxboost.com/" hreflang="en-us">
<link rel="icon" type="image/png" href="images/favicon.png">
<link rel="stylesheet" href="css/main.css">

<noscript>
        <img height="1" width="1" src="https://www.facebook.com/tr?id=133794880723986&ev=PageView&noscript=1"/>
    </noscript>

<script>
(function(w,i,d,g,e,t){w["WidgetTrackerObject"]=g;(w[g]=w[g]||function() {(w[g].q=w[g].q||[]).push(arguments);}),(w[g].ds=1*new Date());(e="script"), (t=d.createElement(e)),(e=d.getElementsByTagName(e)[0]);t.async=1;t.src=i; e.parentNode.insertBefore(t,e);}) (window,"https://widgetbe.com/agent",document,"widgetTracker"); window.widgetTracker("create", "WT-HXIUQLZX"); window.widgetTracker("send", "pageview");
</script>

</head>
<body class="ms-new-theme ">
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MF9R6M5" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<main class="wrap-idx-content idx-wrap-content idx-featured-page">
<header id="header" class="active">
<div class="idx-content-header">
<div class="idx-wrap-logo">
<a class="logo" href="#" title="idxBoost">
<img alt="idxBoost" src="images/unial.png" alt="idxBoost" />
</a>
<button id="btn-responsive" aria-label="Main Menu"><span></span></button>
</div>
<div id="idx-wrap-responsive">
<nav class="idx-main-menu">
<ul>
<li class="idx-item-sm">
<a href="javascript:void(0)" title="Estate Lead Generation List">Real Estate Lead Generation</a>
<ul class="idx-sub-menu">
<li><a class="idx-icon-pt icon-dominate" href="dominate.php" title="Go to Dominate page">Dominate</a></li>
<li><a class="idx-icon-pt icon-generate" href="generate.php" title="Go to Generate page">Generate</a></li>
<li><a class="idx-icon-pt icon-omnipresent" href="omnipresence.php" title="Go to Omnipresence page">Omnipresence</a></li>
<li><a class="idx-icon-pt icon-cproduct" href="compare_products.php" title="Go to Compare Products page">Compare Products</a></li>
</ul>
</li>
<li class="idx-item-sm">
<a href="javascript:void(0)" title="Real Estate Websites list">Real Estate Websites</a>
<ul class="idx-sub-menu">
<li><a href="overview.php" title="Go to Overview page">Overview</a></li>
<li><a class="idx-icon-pt icon-cproduct" href="compare_websites.php" title="Go to Compare websites page">Compare websites</a></li>
</ul>
</li>
<li>
<a href="crm_for_realstate.php" title="Go to CRM For Real Estate page">CRM For Real Estate</a>
</li>
<li>
<a href="features.php" title="Go to Features page">Features</a>
</li>
<li class="idx-item-sm">
<a href="javascript:void(0)" title="Go to Live Demo page">Live Demo</a>
<ul class="idx-sub-menu">
<li><a href="#" target="_blank" title="Go to Basic demo (Open new window)">Basic</a></li>
<li><a href="#" target="_blank" title="Go to Advanced demo (Open new window)">Advanced</a></li>
</ul>
</li>
<li class="idx-btn-content idx-right">
<a href="#" class="nb-button idx-btn-site icon-min-rocket" title="Request Demo">
<span>Request Demo</span>
</a>
</li>
<li class="idx-right">
<a href="#" title="Login">Login</a>
</li>
</ul>
</nav>
</div>
</div>
</header>
<div class="ms-section ms-animate" id="newfeatures-welcome">
<div class="ms-item-imagen">
<img class="ms-lazy" data-real-type="image" data-img="images/03.png" alt="IDXBoost" src="images/temp.png">
</div>
<div class="ms-slider" id="newfeatures-slider">
<div class="ms-item" data-real-type="img-mb" data-pc="images/03.png" data-mb="images/03x.png">
<h2 class="ms-bg-title">Hybrid Map Search IDX Platform with Integrated Video!</h2>
<p>Now here is something you probably never seen before. Your unique BoostBox integrates video and ads to your hybrid map result pages. Get creative with your message!</p>
</div>
<div class="ms-item" data-real-type="img-mb" data-pc="images/02.png" data-mb="images/02x.png">
<h2 class="ms-bg-title">A Mobile-Friendly CRM with Property Alerts & User Story</h2>
<p>A CRM designed to be used on the go, access it from your phone or tablet. It’s always there for you. Automates your lead nurturing while tracking their history.</p>
</div>
<div class="ms-item" data-real-type="img-mb" data-pc="images/044.png" data-mb="images/044x.png">
<h2 class="ms-bg-title">Accessible Updates & Constant Release of New Features!</h2>
<p>IDXBoost it’s the last website you will ever need. Designed to evolve. This innovative platform makes updates and new releases available at a click of a button.</p>
</div>
<div class="ms-item" data-real-type="img-mb" data-pc="images/01.png" data-mb="images/01x.png">
<h2 class="ms-bg-title">Personalized Experience View for Your Users</h2>
<p>IDXBoost gives your users an extra layer of personalization. This innovative widget gives your users quick access to their previously viewed, saved and favorites listings.</p>
</div>
</div>
</div>
<section class="ms-section ms-dg-bg ms-mblock-pc ms-animate" id="responsive-plataform">
<h2 class="ms-title">A Fully Responsive Platform</h2>
<p>IDXBoost modern website platform is designed <span>to be easy to use on any device.</span></p>
<div class="ms-wrap-img">
<span class="ms-pc" data-real-type="background" data-img="images/newfeature-pc.png"></span>
<span class="ms-tablet" data-real-type="background" data-img="images/newfeature-pc.png"></span>
<span class="ms-mobile" data-real-type="background" data-img="images/newfeature-pc.png"></span>
<span class="ms-laptop" data-real-type="background" data-img="images/newfeature-pc.png"></span>
<span class="ms-video"><img class="ms-lazy" data-real-type="image" data-img="images/giphy.gif" alt="" src="images/temp.png"></span>
</div>
</section>
<div class="ms-section ms-animate" id="plataform-skills">
<ul class="ms-list">
<li><span class="ms-icon-engage" data-real-type="background" data-img="images/newfeature-icons.png"></span>
<h2 class="ms-bg-title">Hourly IDX Updates</h2>
<p>The properties in your website will always <span>synchronize with your MLS board.</span></p>
</li>
<li><span class="ms-icon-search" data-real-type="background" data-img="images/newfeature-icons.png"></span>
<h2 class="ms-bg-title">Advanced Map Tools</h2>
<p>Your hybrid visual and map results give you <span>the modern edge expected by users.</span></p>
</li>
<li><span class="ms-icon-phone" data-real-type="background" data-img="images/newfeature-icons.png"></span>
<h2 class="ms-bg-title">Personalized User UX</h2>
<p>For your users, It's more than a platform- it’s <span>a personalized experience.</span></p>
</li>
<li><span class="ms-icon-building" data-real-type="background" data-img="images/newfeature-icons.png"></span>
<h2 class="ms-bg-title">Condo IDX Filters</h2>
<p>Unique tools that allow you to create pages <span>for buildings with active inventory.</span></p>
</li>
<li><span class="ms-icon-engages" data-real-type="background" data-img="images/newfeature-icons.png"></span>
<h2 class="ms-bg-title">Integrated Web & CRM</h2>
<p>Go beyond your tradition CRM and track your users viewed listings and locations and more.</p>
</li>
<li><span class="ms-icon-cloud" data-real-type="background" data-img="images/newfeature-icons.png"></span>
<h2 class="ms-bg-title">Marketing Automations</h2>
<p>Your platform automates touchpoints with <span>your users with drip and property alerts.</span></p>
</li>
</ul>
</div>
<section class="ms-section ms-dg-bg ms-animate" id="plataform-msg">
<h2 class="ms-title">Builds a story for every client</h2>
<p>Everything is saved in your timeline, emails, <span>calls, text and visitors’ listing views.</span></p>
<div class="ms-wrap-img">
<span class="ms-pc" data-real-type="background" data-img="images/newfeature-msg.png"></span>
<span class="ms-pc-avatar" data-real-type="background" data-img="images/newfeature-msg.png"></span>
<span class="ms-pc-qualification" data-real-type="background" data-img="images/newfeature-msg.png"></span>
 <span class="ms-pc-todo" data-real-type="background" data-img="images/newfeature-msg.png"></span>
<span class="ms-pc-msg" data-real-type="background" data-img="images/newfeature-msg.png"></span></div>
</section>
<section class="ms-section ms-animate" id="plataform-solutions">
<h2 class="ms-bg-title">A Complete Solutions For Real Estate Websites, CRM & Lead Generation</h2>
<ul class="ms-list">
<li><span class="ms-icon-website" data-real-type="background" data-img="images/newfeature-skills.png"></span>
<h3 class="ms-bg-title">Real Estate Websites</h3>
<p>Websites for agents, broker agencies, <span>condo buildings and communities with </span>their available inventory.</p>
</li>
<li><span class="ms-icon-crm" data-real-type="background" data-img="images/newfeature-skills.png"></span>
<h3 class="ms-bg-title">Real Estate CRM</h3>
<p>A customer relationship manager designed <span>specifically for real estate. It integrates CRM </span>tools with MLS interactivity.</p>
</li>
<li><span class="ms-icon-generation" data-real-type="background" data-img="images/newfeature-skills.png"></span>
<h3 class="ms-bg-title">Lead Generation</h3>
<p>Lead generation programs for real estate <span>agents and broker agencies from new lead </span>generation to digital omnipresence.</p>
</li>
</ul>
</section>
<div class="ms-section ms-loaded-animate" id="request-demo">
<section class="ms-wrap-footer">
<h2 class="ms-footer-title">Request a Personalized Demo</h2>
<h3 class="ms-bt-title">Call us now at <a href="tel:+18885338736">+1 (888) 533-8736</a></h3>
<p>Fill the form below and one of our representatives will reach out to you<span> at your convenience to demonstrate our products and services.</span></p>
<form name="request_demo" method="post" action="/xhr/lead/request_demo" class="idx-form-bs" id="idx-request-demo-form">
<div class="input-content">
<input type="text" id="request_demo_firstName" name="request_demo[firstName]" required="required" placeholder="First Name" />
<input type="text" id="request_demo_lastName" name="request_demo[lastName]" required="required" placeholder="Last Name" />
<input type="text" id="request_demo_phoneNumber" name="request_demo[phoneNumber]" required="required" placeholder="Phone Number" />
<input type="email" id="request_demo_emailAddress" name="request_demo[emailAddress]" required="required" placeholder="Email" />
</div>
<div class="input-content" style="justify-content:center;">
<script type="text/javascript" src="js/api.js?hl=en" defer async></script><div class="g-recaptcha" data-theme="light" data-size="normal" data-type="image" data-sitekey="6Ldo3B0UAAAAAHGcTiTwuFfPwZEhCqTJztlDUz53"></div><noscript><div style="width: 302px; height: 352px;"><div style="width: 302px; height: 352px; position: relative;"><div style="width: 302px; height: 352px; position: absolute;"><iframe src="https://www.google.com/recaptcha/api/fallback?k=6Ldo3B0UAAAAAHGcTiTwuFfPwZEhCqTJztlDUz53"
                                    frameborder="0" scrolling="no"
                                    style="width: 302px; height:352px; border-style: none;"
                            ></iframe></div><div style="width: 250px; height: 80px; position: absolute; border-style: none; bottom: 21px; left: 25px; margin: 0; padding: 0; right: 25px;"><textarea id="g-recaptcha-response" name="g-recaptcha-response"
                                      class="g-recaptcha-response"
                                      style="width: 250px; height: 80px; border: 1px solid #c1c1c1; margin: 0; padding: 0; resize: none;"
                            ></textarea></div></div></div></noscript>
</div>
<button class="idx-btn-site icon-min-rocket" type="submit" aria-label="Request Demo">
<span>Request Demo</span>
</button>
<input type="hidden" id="request_demo__token" name="request_demo[_token]" value="KHagkdhJ7VupPNiFNrlmjfOoH24CAdYBy4ckPtKtVpw" />
</form>
</section>
<img class="ms-layer ms-loaded" src="images/img_word.png" data-real-type="image" alt="Request a Personalized Demo">
</div>
</main>
<div class="r-overlay"></div>
<footer id="footer">
<div class="idx-footer-top">
<div class="idx-info-company">
<a class="logo" href="#" title="idxBoost">
<img src="images/unial.png" alt="idxBoost" />
</a>
<ul>
<li>
<span>
Support Available
</span>
<span class="idx-text-light">
from 9am - 5pm EST
</span>
<span class="idx-text-light">
Monday - Friday
</span>
</li>
<li>
<span>
Headquarters
</span>
<span class="idx-text-light">
2828 Coral Way #435
</span>
<span class="idx-text-light">
Miami, FL 33145
</span>
</li>
</ul>
</div>
<div class="idx-item-menu-footer">
<h2>
IDX Products
</h2>
<ul>
<li><a href="/lead-generation" title="Go to Real Estate Lead Generation page">Real Estate Lead Generation</a></li>
<li><a href="/real-estate-websites" title="Go to Real Estate Websites page">Real Estate Websites</a></li>
<li><a href="/crm" title="Go to CRM For Real Estate page">CRM For Real Estate</a></li>
<li><a href="/features" title="Go to Features page">Features</a></li>
<li><a href="https://master.idxboost.com/" target="_blank" title="Go to Live Demo (Open new window)">Live Demo</a></li>
</ul>
</div>
<div class="idx-item-menu-footer">
<h2>
Company
</h2>
<ul>
<li>
<a href="/about-us" title="Go to About Us page">
About Us
</a>
<a class="idx-bg-special">
We're Hiring
</a>
</li>
<li>
<a href="https://news.idxboost.com/" title="Go to Blog page">
Blog
</a>
</li>
<li>
<a href="/support" title="Go to Support page">
Support
</a>
</li>
<li>
<a href="/contact" title="Go to Contact page">
Contact
</a>
</li>
<li><a href="/faq" title="Go to FAQ page">FAQ</a></li>
</ul>
</div>
<div class="idx-social-media">
<h2>
Follow Us
</h2>
<ul>
<li>
<a target="_blank" class="icon-facebook" href="https://www.facebook.com/IDX-Boost-279563305877494" title="Go to Facebook">
<span>
Facebook
</span>
</a>
</li>
<li>
<a target="_blank" class="icon-twitter" href="https://twitter.com/idxboost" title="Go to Twitter">
<span>
Twitter
</span>
</a>
</li>
<li>
<a target="_blank" class="icon-instagram" href="https://www.instagram.com/idxboost" title="Go to Instagram">
<span>
Instagram
</span>
</a>
</li>
<li>
<a target="_blank" class="icon-linkedin" href="https://www.linkedin.com/company/26999695" title="Go to Linkedin">
<span>
Linkedin
 </span>
</a>
</li>
<li>
<a target="_blank" class="icon-google" href="https://plus.google.com/u/0/113444352879464388904" title="Go to Google Plus">
<span>
Google +
</span>
</a>
</li>
<li>
<a target="_blank" class="icon-youtube" href="https://www.youtube.com/channel/UCEDMZ5H3JZC74Bydhkdm9HA" title="Go to Youtube">
<span>
Youtube
</span>
</a>
</li>
</ul>
</div>
</div>
<div class="idx-footer-bottom">
<ul>
<li>
<a href="/terms-of-use" title="Go to Terms & Conditions page">
Terms & Conditions
</a>
</li>
<li>
<a href="/privacy-policy" title="Go to Privacy Policy page">
Privacy Policy
</a>
</li>
<li>
<a href="/accessibility" title="Go to Accessibility page">
Accessibility
</a>
</li>
<li class="trem-ico">A company of <a class="ms-trem" href="http://www.tremgroup.com/" target="_blank" title="Go to TREMGROUP (Open new window)">
<span>TREM</span>GROUP</a>
</li>
</ul>
<p>
Copyright 2019, IDX Boost All Rights Reserved.
</p>
</div>
</footer>
<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/dgt-project-master.min.js"></script>
<script type="text/javascript" src="js/greatslider.jquery.min.js"></script>
<script type="text/javascript" src="js/webfont.min.js"></script>
<script type="text/javascript" src="js/main.min.js"></script>
<script>
        (function ($) {
            $(function() {
                //sliderStandar('#slider-testimonial');

                /** FUNCION PARA SCROLL NEXT ***/
                $(document).on('click', '.btn-down', function() {
                    var $nextSection = ($(this).parent().parent().next().offset().top) - 50;
                    $('html, body').animate({scrollTop: $nextSection}, 900);
                });
            });
        })(jQuery);
    </script>
<script>
      (function ($) {
        $(document).on("click", ".gt-request-demo", function(event) {
          event.preventDefault();
          var $nextSection = ($("#request-demo").offset().top) - 100;
          $('html, body').animate({scrollTop: $nextSection}, 900);
        });
      })(jQuery);
    </script>
<script>
    (function($) {
        $(function() {
            $("#idx-request-demo-form").on("submit", function(event) {
                event.preventDefault();

                var _self = $(this);

                _self.find("button").prop("disabled", true);
                _self.find("span").html("Sending, please wait.");

                $.ajax({
                    url: _self.attr("action"),
                    type: "POST",
                    data: _self.serialize(),
                    dataType: "json",
                    success: function(response) {
                        if (response.hasOwnProperty("errors")) {
                            alert("error");
                            _self.find("span").html("Request Demo");
                            _self.find("button").prop("disabled", false);
                        } else {
                            _self.find("span").html("Thank you!");
                        }
                    }
                });
            });
        });
    })(jQuery);
    </script>

<script type="text/javascript">
    var sc_project=11507556;
    var sc_invisible=1;
    var sc_security="1a4bc535";
    var sc_https=1;
    var scJsHost = (("https:" == document.location.protocol) ?
        "https://secure." : "http://www.");
    document.write("<sc"+"ript type='text/javascript' async src='" +
        scJsHost+
        "statcounter.com/counter/counter.js'></"+"script>");
</script>
<noscript><div class="statcounter"><a title="Web Analytics"
                                      href="http://statcounter.com/" target="_blank"><img
                    class="statcounter"
                    src="//c.statcounter.com/11507556/0/1a4bc535/1/" alt="Web
Analytics"></a></div></noscript>

<script id="_agile_min_js" async type="text/javascript" src="js/agile-min.js"> </script>
<script type="text/javascript">
    var Agile_API = Agile_API || {}; Agile_API.on_after_load = function(){
        _agile.set_account('q2brs0h85tb780q54baograigv', 'idxboost');
        _agile.track_page_view();
        _agile_execute_web_rules();};
</script>
<script>
  "use strict";

  !function() {
    var t = window.driftt = window.drift = window.driftt || [];
    if (!t.init) {
      if (t.invoked) return void (window.console && console.error && console.error("Drift snippet included twice."));
      t.invoked = !0, t.methods = [ "identify", "config", "track", "reset", "debug", "show", "ping", "page", "hide", "off", "on" ], 
      t.factory = function(e) {
        return function() {
          var n = Array.prototype.slice.call(arguments);
          return n.unshift(e), t.push(n), t;
        };
      }, t.methods.forEach(function(e) {
        t[e] = t.factory(e);
      }), t.load = function(t) {
        var e = 3e5, n = Math.ceil(new Date() / e) * e, o = document.createElement("script");
        o.type = "text/javascript", o.async = !0, o.crossorigin = "anonymous", o.src = "https://js.driftt.com/include/" + n + "/" + t + ".js";
        var i = document.getElementsByTagName("script")[0];
        i.parentNode.insertBefore(o, i);
      };
    }
  }();
  drift.SNIPPET_VERSION = '0.3.1';
  drift.load('n66kwissxv76');
</script>
<script type="text/javascript">
  var _userway_config = {
    /* uncomment the following line to override default position*/
    /* position: '5', */
    /* uncomment the following line to override default size (values: small, large)*/
    /* size: 'large', */
    /* uncomment the following line to override default language (e.g., fr, de, es, he, nl, etc.)*/
    /* language: 'null', */
    /* uncomment the following line to override color set via widget (e.g., #053f67)*/
    /* color: '#2d68ff', */
    /* uncomment the following line to override type set via widget (1=person, 2=chair, 3=eye, 4=text)*/
    /* type: '2', */
    /* uncomment the following lines to override the accessibility statement*/
    /* statement_text: "Our Accessibility Statement", */
    /* statement_url: "http://www.example.com/accessibility", */
    /* uncomment the following line to override support on mobile devices*/
    /* mobile: true, */
    account: 'IpHpQLkhKh'
  };
</script>
<script type="text/javascript" src="js/widget.js"></script>
</body>
</html>