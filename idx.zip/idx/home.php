
<!DOCTYPE html>
<html lang="en">
<head>

<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':		
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],		
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=		
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);		
})(window,document,'script','dataLayer','GTM-MF9R6M5');</script>

<title>IDX Search for WordPress - IDX Boost</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="#203965">
<meta name="theme-color" content="#203965">
<meta name="msapplication-navbutton-color" content="#203965">
<link rel="alternate" href="#" hreflang="en-us">
<link rel="icon" type="image/png" href="images/favicon.png">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="#">
<noscript>
      <img height="1" width="1" src="#"/>
    </noscript>



<script>
(function(w,i,d,g,e,t){w["WidgetTrackerObject"]=g;(w[g]=w[g]||function() {(w[g].q=w[g].q||[]).push(arguments);}),(w[g].ds=1*new Date());(e="script"), (t=d.createElement(e)),(e=d.getElementsByTagName(e)[0]);t.async=1;t.src=i; e.parentNode.insertBefore(t,e);}) (window,"https://widgetbe.com/agent",document,"widgetTracker"); window.widgetTracker("create", "WT-HXIUQLZX"); window.widgetTracker("send", "pageview");
</script>

</head>
<body class="ms-new-theme ms-home">
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MF9R6M5" height="0" width="0" style="display:none;visibility:hidden" title="Google Tag Maneger"></iframe></noscript>
<main class="idx-wrap-content">
<header id="header">
<div class="idx-content-header">
<div class="idx-wrap-logo">
<a class="logo" href="#" title="idxBoost">
<img alt="idxBoost" src="images/unial.png" alt="idxBoost" />
</a>
<button id="btn-responsive" aria-label="Show Main Menu"><span></span></button>
</div>
<div id="idx-wrap-responsive">
<nav class="idx-main-menu" aria-label="Main menu">
<ul>
<li class="idx-item-sm">
<a href="javascript:void(0)" title="Go to Real Estate Lead Generation">Real Estate Lead Generation</a>
<ul class="idx-sub-menu">
<li><a class="idx-icon-pt icon-dominate" href="dominate.php" title="Go to Dominate">Dominate</a></li>
<li><a class="idx-icon-pt icon-generate" href="generate.php" title="Go to Generate">Generate</a></li>
<li><a class="idx-icon-pt icon-omnipresent" href="omnipresence.php" title="Go to Omnipresence">Omnipresence</a></li>
<li><a class="idx-icon-pt icon-cproduct" href="compare_products.php" title="Go to Compare Products">Compare Products</a></li>
</ul>
</li>
<li class="idx-item-sm">
<a href="javascript:void(0)" title="Go to Real Estate Websites">Real Estate Websites</a>
<ul class="idx-sub-menu">
<li><a href="overview.php" title="Go to Overview">Overview</a></li>
<li><a class="idx-icon-pt icon-cproduct" href="compare_websites.php" title="Go to Compare websites">Compare websites</a></li>
</ul>
</li>
<li>
<a href="crm_for_realstate.php" title="Go to CRM For Real Estate">CRM For Real Estate</a>
</li>
<li>
<a href="features.php" title="Go to Features">Features</a>
</li>
<li class="idx-item-sm">
<a href="javascript:void(0)" title="Go to Live Demo">Live Demo</a>
<ul class="idx-sub-menu">
<li><a href="#" target="_blank" title="Go to Basic demo (Open new window)">Basic</a></li>
<li><a href="#" target="_blank" title="Go to Advanced demo (Open new window)">Advanced</a></li>
</ul>
</li>
<li class="idx-btn-content idx-right">
<a href="#" class="nb-button idx-btn-site icon-min-rocket" title="Request Demo">
<span>Request Demo</span>
</a>
</li>
<li class="idx-right">
<a href="#" title="Login">Login</a>
</li>
</ul>
</nav>
</div>
</div>
</header>
<section class="ms-main ms-animate ms-data-video" id="welcome">
<h1 class="ms-title" id="ms-change-text">
<div class="quotes">Boost your leads. <span>Close more deals.</span></div>
<div class="quotes">Dominate Your <span>Real Estate Market.</span></div>
<div class="quotes">All-In-One Real Estate <span>Marketing Solution.</span></div>
</h1>
<span class="ms-subtitle">Branded Real Estate Websites, CRM and Strategic <span>Lead Generation Programs.</span></span>
<div class="ms-wrap-btn">
<button class="ms-btn btn-down-form" data-step="#request-demo" aria-label="Request Demo">
<span>Request Demo</span>
</button>
<button class="ms-btn btn-icon-play pc-open-video" data-video="https://24e3d2766e918fc4369a-2005f80a01533296a927e19ca48f1dcf.ssl.cf1.rackcdn.com/idxboost/idxboost.3.m4v" aria-label="Watch this video"><span>Watch Video</span></button>
<button class="ms-btn btn-icon-play idx-open-video" data-video="https://24e3d2766e918fc4369a-2005f80a01533296a927e19ca48f1dcf.ssl.cf1.rackcdn.com/idxboost/idxboost.3.m4v" aria-label="Watch this video"><span>Watch Video</span></button>
</div>
<div class="ms-wrap-img">
<div class="ms-layout" data-real-type="sp-video" data-img="video" data-video-mb="https://24e3d2766e918fc4369a-2005f80a01533296a927e19ca48f1dcf.ssl.cf1.rackcdn.com/tremgroup/media.io_trem_vid_cut.m4v" data-video-wb="https://24e3d2766e918fc4369a-2005f80a01533296a927e19ca48f1dcf.ssl.cf1.rackcdn.com/tremgroup/trem_vid.m4v"></div>
<div class="ms-full-video">
<div class="ms-wrap-video"></div>
<button class="ms-close-modal">Close</button>
</div>
</div>
</section>
<section class="ms-section ms-padg">
<section class="ms-section ms-animate ms-mblock-pc" id="real-estate-solution">
<h2 class="ms-bg-title">All-In-One Marketing Real Estate Solution</h2>
<p>IDXBoost provides complete solutions for <strong>Real Estate Websites, CRM, and Lead Generation Programs</strong> for real estate professionals and brokerages alike. Our modern platform is designed to cover all the mediums and tools needed to succeed in today’s complex digital era. A combination of beautiful design, modern technology and easy to use interface.</p>

<div class="ms-wrap-img">
<span class="ms-pc" data-real-type="background" data-img="images/newfeature-pc.png"></span>
<span class="ms-tablet" data-real-type="background" data-img="images/newfeature-pc.png"></span>
<span class="ms-mobile" data-real-type="background" data-img="images/newfeature-pc.png"></span>
<span class="ms-laptop" data-real-type="background" data-img="images/newfeature-pc.png"></span>
<span class="ms-video"><img class="ms-lazy" data-real-type="image" data-img="images/giphy.gif" alt="All-In-One Marketing Real Estate Solution" src="images/temp.png"></span>
</div>
</section>
<div class="ms-bg-block"></div>
</section>
<section class="ms-section ms-dg-bg ms-animate" id="easy-to-use">
<h2 class="ms-bg-title">Modern & Easy-to-Use Real Estate CRM</h2>
<p>Created for real estate professionals by marketing experts. IDXBoost’s powerful CRM <span>brings all the tools you need to succeed and nurture your leads.</span></p>
<div class="ms-wrap-img">
<img class="ms-lazy" data-real-type="image" data-img="images/crm-home.png" alt="Modern & Easy-to-Use Real Estate CRM" src="images/temp.png">
<img class="ms-lazy ms-float-img" data-real-type="image" data-img="images/item-lead.png" alt="IDXBoost’s powerful CRM" src="images/temp.png">
</div>
</section>
<section class="ms-section ms-video-animate ms-animate" id="branded-design">
<article class="ms-article">
<h2 class="ms-bg-title">Branded design and custom landing pages</h2>
<p>IDXBoost's flexible design can be branded to create a unique digital presence for you. It is not just another template. It’s customized to you, your brand, and your target audience.</p>
<div class="ms-wrap-btn ms-center">
<a class="ms-btn ms-new-btn" href="/real-estate-websites" title="Learn More of Branded design and custom landing pages">
<span>Learn More</span>
</a>
</div>
</article>
<div class="ms-wrap-img">
<div class="ms-pc-video">
<span class="ms-pc" data-real-type="background" data-img="images/pc-home-video-skin.png">
<span class="ms-mobile" data-real-type="background" data-img="images/pc-home-video-skin.png"></span>
</span>
<span class="ms-video">
<img class="ms-lazy" data-real-type="image" data-img="images/giphy.gif" alt="IDXBoost's flexible design can be branded to create a unique digital presence for you" src="images/temp.png">
</span>
</div>
</div>
</section>
<section class="ms-section ms-animate" id="market-domination">
<article class="ms-article">
<h2 class="ms-bg-title">Market Domination from search to social</h2>
<p>Generate leads from the top search engines and maximize your presence on the most used social media platforms. Our lead generation programs are designed to make you the authority on your market.</p>
<div class="ms-wrap-btn ms-center">
<a class="ms-btn ms-new-btn" href="/lead-generation/dominate" tilte="Learn More of Market Domination from search to social">
<span>Learn More</span>
</a>
</div>
</article>
<div class="ms-wrap-img">
<div class="ms-tablet-home">
<span class="ms-nebulosa" data-real-type="background" data-img="images/nebulosa-home.png"></span>
<span class="ms-pc" data-real-type="background" data-img="images/media-home.png"></span>
<span class="ms-logo-facebook" data-real-type="background" data-img="images/media-home.png"></span>
<span class="ms-logo-youtube" data-real-type="background" data-img="images/media-home.png"></span>
<span class="ms-logo-google" data-real-type="background" data-img="images/media-home.png"></span>
<span class="ms-logo-linkedin" data-real-type="background" data-img="images/media-home.png"></span>
<span class="ms-logo-instagram" data-real-type="background" data-img="images/media-home.png"></span>
</div>
</div>
</section>
<section class="ms-section ms-animate ms-dft-section" id="dominate-nurturing">
<article class="ms-article">
<h2 class="ms-bg-title">Lead nurturing & automatic property alerts</h2>
<p>A combination of touch-points designed to keep your customer engaged, informed and coming back. Your smart property alerts provide value that keeps the customer interested in your brand.</p>
<div class="ms-wrap-btn ms-center">
<a class="ms-btn ms-new-btn" href="/crm" title="Learn More Lead nurturing & automatic property alerts"><span>Learn More</span></a>
</div>
</article>
<div class="ms-phone">
<span class="ms-phone-a" data-real-type="background" data-img="images/phone.png"></span>
<span class="ms-phone-b" data-real-type="background" data-img="images/phone.png"></span>
<span class="ms-airplane" data-real-type="background" data-img="images/phone.png"></span>
</div>
</section>
<section class="ms-section ms-animate" id="idxboost-agents">
<h2 class="ms-bg-title">What can IDXBoost do for you?</h2>

<p>Let our clients tell you.</p>
<div class="ms-slider ms-agent-slider">
<div class="ms-item">
<a href="javascript:void(0)" class="ms-wrap-img idx-open-video" data-video="https://www.youtube.com/embed/r-qLayO56Ps">
<img class="ms-lazy" data-real-type="image" data-img="images/patrick.jpg" src="images/temp.png" alt="Patrick Ryan">
<span class="ms-playing"></span>
</a>
<div class="ms-description">
<p>We had more exposure than <span>we ever had before... I would</span> highly recommend them!</p>
<h3 class="ms-item-title">Related Realty - Patrick Ryan</h3>

</div>
 </div>
<div class="ms-item">
<a href="javascript:void(0)" class="ms-wrap-img idx-open-video" data-video="https://www.youtube.com/embed/66Dc-lgIRu4">
<img class="ms-lazy" data-real-type="image" data-img="images/lucas.jpg" src="images/temp.png" alt="Lucas Lechuga">
<span class="ms-playing"></span>
</a>
<div class="ms-description">
<p>They’re creative, they get the job done, and they know real estate inside out!</p>
<h3 class="ms-item-title">Miami Condo Investments - Lucas Lechuga</h3>
</div>
</div>
<div class="ms-item">
<a href="javascript:void(0)" class="ms-wrap-img idx-open-video" data-video="https://www.youtube.com/embed/vPKD8TPaBMo">
<img class="ms-lazy" data-real-type="image" data-img="images/david.jpg" src="images/temp.png" alt="David Siddons Group">
<span class="ms-playing"></span>
</a>
<div class="ms-description">
<p>Is due to their efforts that <span>we have been able to grow our</span> business 50% year on year!</p>
<h3 class="ms-item-title">David Siddons Group</h3>
</div>
</div>
<div class="ms-item">
<a href="javascript:void(0)" class="ms-wrap-img idx-open-video" data-video="https://www.youtube.com/embed/EKUMVdDQQO0">
<img class="ms-lazy" data-real-type="image" data-img="images/olga.jpg" src="images/temp.png" alt="Olga Monson">
<span class="ms-playing"></span>
</a>
<div class="ms-description">
<p>They exceeded my expectations! <span>A group of true professionals</span> with innovative ideas!</p>
<h3 class="ms-item-title">Monson Group Real Estate</h3>
</div>
</div>
<div class="ms-item">
<a href="javascript:void(0)" class="ms-wrap-img idx-open-video" data-video="https://www.youtube.com/embed/dOniAO5rk0k">
<img class="ms-lazy" data-real-type="image" data-img="images/lucasbo.jpg" src="images/temp.png" alt="Lucas Boccheciampe">
<span class="ms-playing"></span>
</a>
<div class="ms-description">
<p>TREMGROUP team feels like an in-house team</p>
<h3 class="ms-item-title">Lucas Boccheciampe</h3>
</div>
</div>
<div class="ms-item">
<a href="javascript:void(0)" class="ms-wrap-img idx-open-video" data-video="https://www.youtube.com/embed/fVH5TntGQhc">
<img class="ms-lazy" data-real-type="image" data-img="images/marder.jpg" src="images/temp.png" alt="Lucas Boccheciampe">
<span class="ms-playing"></span>
</a>
<div class="ms-description">
<p>I credit TREMGroup <span>with taking my business</span> to another level!</p>
<h3 class="ms-item-title">Marder Group - David Marder</h3>
</div>
</div>
<div class="ms-item">
<a href="javascript:void(0)" class="ms-wrap-img idx-open-video" data-video="https://www.youtube.com/embed/-rS_qHByjR0">
<img class="ms-lazy" data-real-type="image" data-img="images/ross.jpg" src="images/temp.png" alt="Ross Milroy">
<span class="ms-playing"></span>
</a>
<div class="ms-description">
<p>TREMGroup maximizes my return on investment!</p>
<h3 class="ms-item-title">Ross Milroy</h3>
</div>
</div>
<div class="ms-item">
<a href="javascript:void(0)" class="ms-wrap-img idx-open-video" data-video="https://www.youtube.com/embed/uDpnaN7MTsU">
<img class="ms-lazy" data-real-type="image" data-img="images/elliot.jpg" src="images/temp.png" alt="Elliot Lee">
<span class="ms-playing"></span>
</a>
<div class="ms-description">
<p>When you hire TREMGroup, you hire and entire team that not only works for you but works with you.</p>
<h3 class="ms-item-title">Lina & Elliot Group - Elliot Lee</h3>
</div>
</div>
<div class="ms-item">
<a href="javascript:void(0)" class="ms-wrap-img idx-open-video" data-video="https://www.youtube.com/embed/7r-HyqnEXTU">
<img class="ms-lazy" data-real-type="image" data-img="images/julianj.jpg" src="images/temp.png" alt="Elliot Lee">
<span class="ms-playing"></span>
</a>
<div class="ms-description">
<p>My revenue has increased consistently because my website MiaWaterfront.com ranks #1 on Google.</p>
<h3 class="ms-item-title">Julian Johnston Team</h3>
</div>
</div>
 </div>
</section>
<div class="ms-section ms-animate" id="request-demo">
<section class="ms-wrap-footer">
<h2 class="ms-footer-title">Request a Personalized Demo</h2>
<h3 class="ms-bt-title">Call us now at <a href="tel:+18885338736">+1 (888) 533-8736</a></h3>
<p>Fill the form below and one of our representatives will reach out to you<span> at your convenience to demonstrate our products and services.</span></p>
<form name="request_demo" method="post" action="/xhr/lead/request_demo" class="idx-form-bs" id="idx-request-demo-form">
<div class="input-content">
<input type="text" id="request_demo_firstName" name="request_demo[firstName]" required="required" placeholder="First Name" />
<input type="text" id="request_demo_lastName" name="request_demo[lastName]" required="required" placeholder="Last Name" />
<input type="text" id="request_demo_phoneNumber" name="request_demo[phoneNumber]" required="required" placeholder="Phone Number" />
<input type="email" id="request_demo_emailAddress" name="request_demo[emailAddress]" required="required" placeholder="Email" />
</div>
<div class="input-content" style="justify-content:center;">
<script type="text/javascript" src="js/api.js?hl=en" defer async></script><div class="g-recaptcha" data-theme="light" data-size="normal" data-type="image" data-sitekey="6Ldo3B0UAAAAAHGcTiTwuFfPwZEhCqTJztlDUz53"></div><noscript><div style="width: 302px; height: 352px;"><div style="width: 302px; height: 352px; position: relative;"><div style="width: 302px; height: 352px; position: absolute;"><iframe src="https://www.google.com/recaptcha/api/fallback?k=6Ldo3B0UAAAAAHGcTiTwuFfPwZEhCqTJztlDUz53"
                                    frameborder="0" scrolling="no"
                                    style="width: 302px; height:352px; border-style: none;"
                            ></iframe></div><div style="width: 250px; height: 80px; position: absolute; border-style: none; bottom: 21px; left: 25px; margin: 0; padding: 0; right: 25px;"><textarea id="g-recaptcha-response" name="g-recaptcha-response"
                                      class="g-recaptcha-response"
                                      style="width: 250px; height: 80px; border: 1px solid #c1c1c1; margin: 0; padding: 0; resize: none;"
                            ></textarea></div></div></div></noscript>
</div>
<button class="idx-btn-site icon-min-rocket" type="submit" aria-label="Request Demo">
<span>Request Demo</span>
</button>
<input type="hidden" id="request_demo__token" name="request_demo[_token]" value="KHagkdhJ7VupPNiFNrlmjfOoH24CAdYBy4ckPtKtVpw" />
</form>
</section>
<img class="ms-layer ms-loaded" src="images/img_word.png" data-real-type="image" alt="Request a Personalized Demo">
</div>
</main>
<div class="r-overlay"></div>
<footer id="footer">
<div class="idx-footer-top">
<div class="idx-info-company">
<a class="logo" href="#" title="idxBoost">
<img src="images/unial.png" alt="IDXBoost" />
</a>
<ul>
<li>
<span>
Support Available
</span>
<span class="idx-text-light">
from 9am - 5pm EST
</span>
<span class="idx-text-light">
Monday - Friday
</span>
</li>
<li>
<span>
Headquarters
</span>
<span class="idx-text-light">
2828 Coral Way #435
</span>
<span class="idx-text-light">
Miami, FL 33145
</span>
</li>
</ul>
</div>
<div class="idx-item-menu-footer">
<h2>
IDX Products
</h2>
<ul>
 <li><a href="/lead-generation" title="Go to Real Estate Lead Generation page">Real Estate Lead Generation</a></li>
<li><a href="/real-estate-websites" title="Go to Real Estate Websites page">Real Estate Websites</a></li>
<li><a href="/crm" title="Go to CRM For Real Estate page">CRM For Real Estate</a></li>
<li><a href="/features" title="Go to Features page">Features</a></li>
<li><a href="https://master.idxboost.com/" target="_blank" title="Go to Live Demo (Open new window)">Live Demo</a></li>
</ul>
</div>
<div class="idx-item-menu-footer">
<h2>
Company
</h2>
<ul>
<li>
<a href="/about-us" title="Go to About Us page">
About Us
</a>
<span class="idx-bg-special">
We're Hiring
</span>
</li>
<li>
<a href="https://news.idxboost.com/" title="Go to Blog page">
Blog
</a>
</li>
<li>
<a href="/support" title="Go to Support page">
Support
</a>
</li>
<li>
<a href="/contact" title="Go to Contact page">
Contact
</a>
</li>
<li><a href="/faq" title="Go to FAQ page">FAQ</a></li>
</ul>
</div>
<div class="idx-social-media">
<h2>
Follow Us
</h2>
<ul>
<li>
<a target="_blank" class="icon-facebook" href="https://www.facebook.com/IDX-Boost-279563305877494" title="Navigate to Facebook">
<span>
Facebook
</span>
</a>
</li>
<li>
<a target="_blank" class="icon-twitter" href="https://twitter.com/idxboost" title="Navigate to Twitter">
<span>
Twitter
</span>
</a>
</li>
<li>
<a target="_blank" class="icon-instagram" href="https://www.instagram.com/idxboost" title="Navigate to Instagram">
<span>
Instagram
</span>
</a>
</li>
<li>
<a target="_blank" class="icon-linkedin" href="https://www.linkedin.com/company/26999695" title="Navigate to Linkedin">
<span>
Linkedin
</span>
</a>
</li>
<li>
<a target="_blank" class="icon-google" href="https://plus.google.com/u/0/113444352879464388904" title="Navigate to Google Plus">
<span>
Google +
</span>
</a>
</li>
<li>
<a target="_blank" class="icon-youtube" href="https://www.youtube.com/channel/UCEDMZ5H3JZC74Bydhkdm9HA" title="Navigate to Youtube">
<span>
Youtube
</span>
</a>
</li>
</ul>
</div>
</div>
<div class="idx-footer-bottom">
<ul>
<li>
<a href="/terms-of-use" title="Go to Terms & Conditions page">
Terms & Conditions
</a>
</li>
<li>
<a href="/privacy-policy" title="Go to Privacy Policy page">
Privacy Policy
</a>
</li>
<li class="trem-ico">A company of <a class="ms-trem" href="http://www.tremgroup.com/" target="_blank" title="Go to TREMGROUP (Open new window)"><span>TREM</span>GROUP</a></li>
</ul>
<p>
Copyright 2019, IDX Boost All Rights Reserved.
</p>
</div>
</footer>
<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/dgt-project-master.min.js"></script>
<script type="text/javascript" src="js/greatslider.jquery.min.js"></script>
<script type="text/javascript" src="js/webfont.min.js"></script>
<script type="text/javascript" src="js/main.min.js"></script>
<script>
      (function ($) {
          /** FUNCION PARA SCROLL NEXT ***/
          $(document).on('click', '.btn-down', function() {
              var $nextSection = ($(this).parent().parent().next().offset().top) - 50;
              $('html, body').animate({scrollTop: $nextSection}, 900);
          });


          $(window).on('load', function(){
            setTimeout(function(){ 
              LoadDriftWidget();
              $("#footer").after('<div id="awwwards" style="position: fixed; z-index: 999; transform: translateY(-50%); top: 50%;  right: 0"><a href="https://www.awwwards.com/sites/idxboost-com" target="_blank" title="View the Nomination (Open new window)"><svg width="53.08" height="171.358"><path class="js-color-bg" fill="#5ABDB2" d="M0 0h53.08v171.358H0z"></path><g class="js-color-text" fill="#fff"><path d="M20.048 153.585v-2.002l6.752-3.757h-6.752v-1.9h10.23v2.002l-6.752 3.757h6.752v1.9zM29.899 142.382a3.317 3.317 0 0 1-1.359 1.293c-.575.297-1.223.446-1.944.446-.721 0-1.369-.149-1.944-.446a3.317 3.317 0 0 1-1.359-1.293c-.331-.564-.497-1.232-.497-2.003 0-.769.166-1.437.497-2.002a3.332 3.332 0 0 1 1.359-1.294c.575-.297 1.224-.445 1.944-.445.722 0 1.369.148 1.944.445a3.326 3.326 0 0 1 1.359 1.294c.33.565.496 1.233.496 2.002.001.77-.166 1.438-.496 2.003m-1.703-3.348c-.435-.331-.967-.497-1.601-.497s-1.167.166-1.601.497c-.434.332-.65.78-.65 1.345s.217 1.014.65 1.346c.434.33.967.496 1.601.496s1.166-.166 1.601-.496c.434-.332.649-.78.649-1.346.001-.565-.215-1.013-.649-1.345M22.912 134.996v-1.812h1.185c-.43-.283-.752-.593-.973-.929-.219-.336-.329-.732-.329-1.19 0-.479.127-.902.38-1.272.254-.37.635-.633 1.141-.79-.478-.262-.851-.591-1.118-.985a2.221 2.221 0 0 1-.402-1.265c0-.682.2-1.218.599-1.607.4-.391.957-.585 1.668-.585h5.218v1.812H25.37c-.682 0-1.023.303-1.023.907 0 .467.264.85.789 1.146.527.299 1.286.446 2.28.446h2.865v1.813H25.37c-.682 0-1.023.303-1.023.906 0 .468.275.851.826 1.147.551.298 1.352.446 2.404.446h2.704v1.812h-7.369zM21.626 122.457c-.225.224-.502.336-.833.336s-.608-.112-.833-.336a1.128 1.128 0 0 1-.336-.833c0-.331.111-.609.336-.833.225-.225.502-.336.833-.336s.608.111.833.336c.225.224.337.502.337.833 0 .332-.112.608-.337.833m1.286-1.739h7.366v1.813h-7.366v-1.813zM22.912 118.668v-1.812h1.185a3.348 3.348 0 0 1-.951-1.009 2.434 2.434 0 0 1-.351-1.272c0-.681.19-1.229.57-1.644.38-.414.931-.621 1.651-.621h5.263v1.812h-4.722c-.418 0-.727.096-.92.285-.195.19-.293.447-.293.769 0 .302.116.58.351.833.233.254.577.458 1.03.613.453.156.992.234 1.615.234h2.938v1.812h-7.366zM29.833 109.129a3.33 3.33 0 0 1-1.432 1.169 4.535 4.535 0 0 1-1.805.373 4.537 4.537 0 0 1-1.807-.373c-.579-.248-1.057-.638-1.432-1.169s-.563-1.196-.563-1.995c0-.771.183-1.413.549-1.93a3.28 3.28 0 0 1 1.382-1.141 4.221 4.221 0 0 1 1.709-.364h.746v5.071c.447-.02.838-.183 1.168-.49.332-.307.498-.724.498-1.248 0-.41-.093-.754-.277-1.031-.186-.278-.473-.529-.863-.753l.542-1.462c.69.303 1.224.724 1.592 1.265.371.541.556 1.235.556 2.083 0 .799-.188 1.464-.563 1.995m-4.085-3.574c-.41.088-.746.261-1.009.52-.262.258-.395.61-.395 1.06 0 .428.137.784.409 1.067.272.282.604.458.994.525v-3.172zM29.833 100.878c-.375.531-.852.921-1.432 1.169a4.552 4.552 0 0 1-3.612 0c-.579-.248-1.057-.638-1.432-1.169s-.563-1.196-.563-1.995c0-.77.183-1.412.549-1.93a3.278 3.278 0 0 1 1.382-1.14 4.222 4.222 0 0 1 1.709-.365h.746v5.072a1.794 1.794 0 0 0 1.168-.49c.332-.307.498-.724.498-1.249 0-.41-.093-.753-.277-1.031-.186-.277-.473-.528-.863-.753l.542-1.462c.69.302 1.224.724 1.592 1.265.371.541.556 1.234.556 2.083 0 .799-.188 1.464-.563 1.995m-4.085-3.573c-.41.088-.746.261-1.009.519-.262.258-.395.611-.395 1.06 0 .429.137.784.409 1.067.272.282.604.458.994.526v-3.172zM35.481 16.926l-4.782 14.969h-3.266l-2.584-9.682-2.584 9.682h-3.268l-4.781-14.969h3.713l2.673 10.276 2.524-10.276h3.445l2.524 10.276 2.674-10.276zM37.979 27.083c1.426 0 2.495 1.068 2.495 2.495 0 1.425-1.069 2.495-2.495 2.495-1.425 0-2.495-1.07-2.495-2.495-.001-1.427 1.07-2.495 2.495-2.495"></path></g></svg></a></div>');
            }, 1000);
          });

          /** FUNCION VIDEO WELCOME ***/
          $(document).on('click', '.ms-btn.pc-open-video', function() {
            var urlVideo = $(this).attr("data-video");
            $(".ms-full-video .ms-wrap-video").html('<video src="'+urlVideo+'" class="ms-video-full" title="IDXBoost" autoplay loop playsinline></video>');
            $(".ms-full-video").addClass("active");
          });

          $(document).on('click', '.ms-full-video .ms-close-modal', function() {
            $(".ms-full-video").removeClass("active");
            setTimeout(function(){
              $(".ms-full-video .ms-wrap-video").empty();
            }, 500);
          });

          $(window).on('load resize', function () {
            var sizeWindows = $(window).width();
            if(sizeWindows < 992){
              var videoActive  = $(".ms-full-video .ms-wrap-video").html();
              if(videoActive.length){
                $(".ms-full-video").removeClass("active");
                  setTimeout(function(){
                  $(".ms-full-video .ms-wrap-video").empty();
                }, 500);
              }
            }
          });

      })(jQuery);
    </script>

<script type="text/javascript">
      var sc_project=11507556;
      var sc_invisible=1;
      var sc_security="1a4bc535";
      var sc_https=1;
      var scJsHost = (("https:" == document.location.protocol) ?
          "https://secure." : "http://www.");
      document.write("<sc"+"ript type='text/javascript' async src='" +
          scJsHost+
          "statcounter.com/counter/counter.js'></"+"script>");
    </script>
<noscript>
      <div class="statcounter"><a title="Web Analytics"
        href="http://statcounter.com/" target="_blank"><img
        class="statcounter"
        src="//c.statcounter.com/11507556/0/1a4bc535/1/" alt="Web
        Analytics"></a></div>
    </noscript>

<script id="_agile_min_js" async type="text/javascript" src="js/agile-min.js"> </script>
<script type="text/javascript">
        var Agile_API = Agile_API || {}; Agile_API.on_after_load = function(){
            _agile.set_account('q2brs0h85tb780q54baograigv', 'idxboost');
            _agile.track_page_view();
            _agile_execute_web_rules();};
    </script>
<script>
       (function ($) {
           $(document).on("click", ".gt-request-demo", function(event) {
                event.preventDefault();
                var $nextSection = ($("#request-demo").offset().top) - 100;
                $('html, body').animate({scrollTop: $nextSection}, 900);
            });
       })(jQuery);
   </script>
<script>
      (function($) {
          $(function() {
              $("#idx-request-demo-form").on("submit", function(event) {
                  event.preventDefault();

                  var _self = $(this);

                  _self.find("button").prop("disabled", true);
                  _self.find("span").html("Sending, please wait.");

                  $.ajax({
                      url: _self.attr("action"),
                      type: "POST",
                      data: _self.serialize(),
                      dataType: "json",
                      success: function(response) {
                          if (response.hasOwnProperty("errors")) {
                           alert("error");
                            _self.find("span").html("Request Demo");
                            _self.find("button").prop("disabled", false);
                          } else {
                            _self.find("span").html("Thank you!");
                          }
                      }
                  });
              });
          });
      })(jQuery);

      $(window).on('load scroll', function(){
        var $videoData = $(".ms-data-video");
        if ($videoData.length) {
          if (!$videoData.hasClass('ms-video-active')) {
            $videoData.addClass('ms-video-active');
            var $videoUrl = $videoData.find('#idx-video').attr('data-video');
            $("#idx-video").attr('src', $videoUrl).removeAttr('data-video').addClass('fadeIn animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
              $(this).removeClass('fadeIn animated').addClass('active');
            });
          }
        }
      });
  </script>
<script>
        function creaIframeVideo(elBoton){
        var $urlVideo = elBoton.attr('data-video');
            if ($urlVideo !== undefined) {
            var $urlVideo = $urlVideo.toString();
            if ($urlVideo.indexOf('youtube') !== -1) {
                var et = $urlVideo.lastIndexOf('&')
                if(et !== -1){
                $urlVideo = $urlVideo.substring(0, et)
                }
                var embed = $urlVideo.indexOf('embed');
                if (embed !== -1) {
                    $urlVideo = 'https://www.youtube.com/watch?v=' + $urlVideo.substring(embed + 6, embed + 17);
                }
                var srcVideo = 'https://www.youtube.com/embed/' + $urlVideo.substring($urlVideo.length - 11, $urlVideo.length) + '?autoplay=1;rel=0&showinfo=0';
                return '<iframe allow="autoplay; encrypted-media" src="' + srcVideo + '" title="IDXBoost" frameborder="0" allowfullscreen></iframe>';
            } else if ($urlVideo.indexOf('vimeo') !== -1) { // es un video de Vimeo, EJM: https://vimeo.com/206418873
                var srcVideo = 'https://player.vimeo.com/video/' + $urlVideo.substring(($urlVideo.indexOf('.com') + 5), $urlVideo.length).replace('/', '');
                return '<iframe allow="autoplay; encrypted-media" src="' + srcVideo + '" title="IDXBoost" frameborder="0" allowfullscreen></iframe>';
            } else {
                return '<video src="' + $urlVideo + '" width="100%" height="100%" title="IDXBoost" autoplay playsinline>';
            }
          }
        }

        (function ($) {
            $(function() {
                /*** FUNCION PARA MOSTRAR EL VIDEO ***/
                $(document).on('click', '.idx-open-video', function() {
                    var $iframeVideo = creaIframeVideo($(this));
                    if ($iframeVideo) {
                        var $wrapperVideo = $('#wrapper-video');
                        $wrapperVideo = $("body");
                        $wrapperVideo.append('<div class="video-inside"><div class="iframe">' + $iframeVideo + '</div><button class="close-vi" aria-label="Close">x</button><div class="bg-close"></div></div>');
                        setTimeout(function(){
                            $wrapperVideo.find('.video-inside').css('left','0');
                        }, 500)
                    }
                });

                $(document).on('click', '.close-vi, .bg-close', function(){
                    var $elParent = $(this).parent();
                    $("body").find('.video-inside').css('left','-100%');
                    setTimeout(function(){
                        $elParent.remove();
                    }, 1200)
                });
            });
        })(jQuery);
    </script>


<script>
      "use strict";

      function LoadDriftWidget() {
        var t = window.driftt = window.drift = window.driftt || [];
        if (!t.init) {
          if (t.invoked) return void (window.console && console.error && console.error("Drift snippet included twice."));
          t.invoked = !0, t.methods = [ "identify", "config", "track", "reset", "debug", "show", "ping", "page", "hide", "off", "on" ], 
          t.factory = function(e) {
            return function() {
              var n = Array.prototype.slice.call(arguments);
              return n.unshift(e), t.push(n), t;
            };
          }, t.methods.forEach(function(e) {
            t[e] = t.factory(e);
          }), t.load = function(t) {
            var e = 3e5, n = Math.ceil(new Date() / e) * e, o = document.createElement("script");
            o.type = "text/javascript", o.async = !0, o.crossorigin = "anonymous", o.src = "https://js.driftt.com/include/" + n + "/" + t + ".js";
            var i = document.getElementsByTagName("script")[0];
            i.parentNode.insertBefore(o, i);
          };
        }
        drift.SNIPPET_VERSION = '0.3.1';
        drift.load('n66kwissxv76');
      };
    </script>

</body>
</html>